// Menyambut pengguna di halaman utama
window.addEventListener('load', function() {
    const userName = prompt("Masukkan nama Anda:"); // Mengambil nama pengguna
    document.getElementById('userName').textContent = userName ? userName : 'Pengguna';
});

// Validasi form dan tampilkan hasil
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Mencegah pengiriman form yang default

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const message = document.getElementById('message').value;

    // Tampilkan hasil ke dalam #formOutput
    const output = `
        <h3>Terima Kasih, ${name}!</h3>
        <p>Email: ${email}</p>
        <p>Telepon: ${phone}</p>
        <p>Pesan: ${message}</p>
    `;
    document.getElementById('formOutput').innerHTML = output;
});